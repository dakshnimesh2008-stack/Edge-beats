# EDGE BEATS
Audio-reactive screen-edge visualizer for Android (Kotlin, Jetpack Compose, Material 3).
Not a music player: it draws animated effects around the screen edges while other apps play audio.
Package: `com.daksh.edgebeats` · minSdk 26 · targetSdk 34.
Build: `./gradlew assembleDebug` (JDK 17). Unit tests: `./gradlew testDebugUnitTest`.
Privacy: no audio is recorded, stored or transmitted. The optional audio-reactive mode only reads
spectrum data from Android's Visualizer API and needs the audio permission.
