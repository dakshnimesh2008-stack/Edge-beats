package com.daksh.edgebeats.visualizer

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import com.daksh.edgebeats.data.EdgeSettings
import com.daksh.edgebeats.data.EdgeStyle
import com.daksh.edgebeats.data.Palette
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

private val RGB_COLORS = listOf(Color(0xFFFF0033), Color(0xFF00FF55), Color(0xFF2255FF))

fun paletteAt(colors: List<Color>, t: Float): Color {
    val n = colors.size
    if (n == 1) return colors[0]
    val x = (((t % 1f) + 1f) % 1f) * n
    val i = x.toInt() % n
    return lerp(colors[i], colors[(i + 1) % n], x - x.toInt())
}

private fun cycleBrush(colors: List<Color>, phase: Float, center: Offset, steps: Int = 12): Brush {
    val list = ArrayList<Color>(steps + 1)
    for (i in 0 until steps) list.add(paletteAt(colors, i / steps.toFloat() + phase))
    list.add(list[0])
    return Brush.sweepGradient(list, center)
}

fun DrawScope.drawEdgeEffect(s: EdgeSettings, st: RenderState, paths: EdgePaths, intensity: Float) {
    if (intensity <= 0.01f) return
    val a = (s.brightness * intensity).coerceIn(0f, 1f)
    val c = Offset(size.width / 2f, size.height / 2f)
    val base = s.thicknessDp.dp.toPx()
    when (s.style) {
        EdgeStyle.THIN_BORDER ->
            border(s, paths, cycleBrush(s.palette.colors, st.phase * 0.3f, c), a, (base * 0.5f).coerceAtLeast(1.5f) * (1f + 0.5f * st.level), 0f)
        EdgeStyle.NEON_GLOW ->
            border(s, paths, cycleBrush(s.palette.colors, st.phase * 0.5f, c), a, base * (0.8f + 0.6f * st.level), s.glow)
        EdgeStyle.RGB_GAMING ->
            border(s, paths, cycleBrush(RGB_COLORS, st.phase * 3f, c), a, base * (0.9f + 0.5f * st.level), s.glow * 0.8f)
        EdgeStyle.RAINBOW_FLOW ->
            border(s, paths, cycleBrush(Palette.RAINBOW.colors, st.phase, c, 18), a, base * 1.2f, s.glow)
        EdgeStyle.EQUALIZER_BARS -> bars(s, st, a)
        EdgeStyle.AUDIO_WAVE -> waves(s, st, a)
        EdgeStyle.CORNER_GLOW -> cornerGlow(s, st, a)
        EdgeStyle.MINIMAL_PULSE -> {
            val pulse = 0.35f + 0.65f * st.level.coerceIn(0f, 1f)
            border(s, paths, cycleBrush(s.palette.colors, st.phase * 0.2f, c), a * pulse, (base * 0.6f).coerceAtLeast(1.5f) * (1f + 1.5f * st.level), s.glow * 0.3f)
        }
        EdgeStyle.DUAL_LINE -> dualLine(s, st, paths, a)
        EdgeStyle.AMBIENT_GRADIENT -> ambient(s, st, a)
        EdgeStyle.CORNER_TRAILS -> trails(s, st, paths, a)
        EdgeStyle.MIXED -> {
            ambient(s, st, a * 0.45f)
            cornerGlow(s, st, a * 0.7f)
            border(s, paths, cycleBrush(s.palette.colors, st.phase * 0.4f, c), a, (base * 0.6f).coerceAtLeast(1.5f), s.glow * 0.4f)
        }
    }
}

private fun DrawScope.border(s: EdgeSettings, paths: EdgePaths, brush: Brush, a: Float, width: Float, glow: Float) {
    val base = s.thicknessDp.dp.toPx()
    val path = paths.get(size.width, size.height, base / 2f, s.cornerRadiusDp.dp.toPx(), s)
    if (glow > 0.02f) {
        drawPath(path, brush, alpha = (a * 0.12f * (1f + glow)).coerceAtMost(1f),
            style = Stroke(width * (1f + 6f * glow), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(path, brush, alpha = (a * 0.28f * (1f + glow)).coerceAtMost(1f),
            style = Stroke(width * (1f + 2.5f * glow), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
    drawPath(path, brush, alpha = a, style = Stroke(width, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

private fun DrawScope.bars(s: EdgeSettings, st: RenderState, a: Float) {
    val w = size.width
    val h = size.height
    val base = s.thicknessDp.dp.toPx()
    val maxLen = barMaxLength(w, h)
    val cols = s.palette.colors
    fun side(enabled: Boolean, count: Int, x0: Float, y0: Float, x1: Float, y1: Float, nx: Float, ny: Float, seed: Int) {
        if (!enabled) return
        val len = kotlin.math.hypot(x1 - x0, y1 - y0)
        val bw = (len / count * 0.55f).coerceIn(2f, base * 3f + 4f)
        for (i in 0 until count) {
            val t = (i + 0.5f) / count
            if (s.cornersOnly && t > 0.2f && t < 0.8f) continue
            val v = st.band((abs(2f * t - 1f) + seed * 0.07f) % 1f)
            val l = base + v * maxLen
            val px = x0 + (x1 - x0) * t
            val py = y0 + (y1 - y0) * t
            drawLine(paletteAt(cols, t * 0.8f + st.phase * 0.5f), Offset(px, py), Offset(px + nx * l, py + ny * l),
                strokeWidth = bw, cap = StrokeCap.Round, alpha = a)
        }
    }
    side(s.bottom, 36, 0f, h, w, h, 0f, -1f, 0)
    side(s.top, 36, 0f, 0f, w, 0f, 0f, 1f, 4)
    side(s.left, 20, 0f, 0f, 0f, h, 1f, 0f, 8)
    side(s.right, 20, w, 0f, w, h, -1f, 0f, 12)
}

private fun DrawScope.waves(s: EdgeSettings, st: RenderState, a: Float) {
    val w = size.width
    val h = size.height
    val base = s.thicknessDp.dp.toPx()
    val amp = base + barMaxLength(w, h) * 0.5f * (0.3f + st.level * 1.5f).coerceAtMost(1.5f)
    val cols = s.palette.colors
    val tau = (2 * PI).toFloat()
    fun wave(enabled: Boolean, x0: Float, y0: Float, x1: Float, y1: Float, nx: Float, ny: Float, shift: Float) {
        if (!enabled) return
        val path = Path()
        val pts = 64
        for (i in 0..pts) {
            val t = i / pts.toFloat()
            val v = sin((t * 3f + st.time * 0.6f + shift) * tau) * 0.6f +
                sin((t * 7f - st.time * 0.95f) * tau) * 0.4f * st.band(t)
            val off = base * 1.2f + amp * (0.55f + 0.45f * v)
            val px = x0 + (x1 - x0) * t + nx * off
            val py = y0 + (y1 - y0) * t + ny * off
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        val color = paletteAt(cols, shift + st.phase)
        if (s.glow > 0.02f) drawPath(path, color, alpha = a * 0.25f * s.glow,
            style = Stroke(base * (1f + 4f * s.glow), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(path, color, alpha = a, style = Stroke(base * 0.7f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
    wave(s.bottom, 0f, h, w, h, 0f, -1f, 0f)
    wave(s.top, 0f, 0f, w, 0f, 0f, 1f, 0.25f)
    wave(s.left, 0f, 0f, 0f, h, 1f, 0f, 0.5f)
    wave(s.right, w, 0f, w, h, -1f, 0f, 0.75f)
}

private fun DrawScope.cornerGlow(s: EdgeSettings, st: RenderState, a: Float) {
    val w = size.width
    val h = size.height
    val rad = min(w, h) * (0.16f + 0.12f * s.glow) * (0.8f + 0.6f * st.level)
    val corners = listOf(
        Triple(Offset(0f, 0f), s.top || s.left, 0),
        Triple(Offset(w, 0f), s.top || s.right, 1),
        Triple(Offset(w, h), s.bottom || s.right, 2),
        Triple(Offset(0f, h), s.bottom || s.left, 3)
    )
    for ((p, on, i) in corners) {
        if (!on) continue
        val col = paletteAt(s.palette.colors, i / 4f + st.phase)
        drawCircle(
            Brush.radialGradient(listOf(col.copy(alpha = 0.5f + 0.5f * s.glow), Color.Transparent), center = p, radius = rad),
            radius = rad, center = p, alpha = a
        )
    }
}

private fun DrawScope.dualLine(s: EdgeSettings, st: RenderState, paths: EdgePaths, a: Float) {
    val base = s.thicknessDp.dp.toPx()
    val r = s.cornerRadiusDp.dp.toPx()
    val outer = paths.get(size.width, size.height, base / 2f + 1f, r, s)
    val inner = paths.get(size.width, size.height, base * 2.4f, (r - base).coerceAtLeast(0f), s)
    val cols = s.palette.colors
    val c1 = paletteAt(cols, st.phase)
    val c2 = paletteAt(cols, st.phase + 0.5f)
    if (s.glow > 0.02f) drawPath(outer, c1, alpha = a * 0.2f * s.glow,
        style = Stroke(base * (1.5f + 3f * st.low) * (1f + 2f * s.glow), cap = StrokeCap.Round, join = StrokeJoin.Round))
    drawPath(outer, SolidColor(c1), alpha = a,
        style = Stroke(base * (0.5f + 1.5f * st.low), cap = StrokeCap.Round, join = StrokeJoin.Round))
    drawPath(inner, SolidColor(c2), alpha = a,
        style = Stroke(base * (0.35f + 1.2f * st.high), cap = StrokeCap.Round, join = StrokeJoin.Round))
}

private fun DrawScope.ambient(s: EdgeSettings, st: RenderState, a: Float) {
    val w = size.width
    val h = size.height
    val base = s.thicknessDp.dp.toPx()
    val depth = (base * 6f + min(w, h) * 0.05f) * (0.8f + 0.7f * st.level)
    fun col(k: Int) = paletteAt(s.palette.colors, st.phase + k * 0.25f)
    if (s.top) drawRect(Brush.verticalGradient(listOf(col(0), Color.Transparent), startY = 0f, endY = depth),
        topLeft = Offset(0f, 0f), size = Size(w, depth), alpha = a)
    if (s.bottom) drawRect(Brush.verticalGradient(listOf(Color.Transparent, col(2)), startY = h - depth, endY = h),
        topLeft = Offset(0f, h - depth), size = Size(w, depth), alpha = a)
    if (s.left) drawRect(Brush.horizontalGradient(listOf(col(3), Color.Transparent), startX = 0f, endX = depth),
        topLeft = Offset(0f, 0f), size = Size(depth, h), alpha = a)
    if (s.right) drawRect(Brush.horizontalGradient(listOf(Color.Transparent, col(1)), startX = w - depth, endX = w),
        topLeft = Offset(w - depth, 0f), size = Size(depth, h), alpha = a)
}

private fun DrawScope.trails(s: EdgeSettings, st: RenderState, paths: EdgePaths, a: Float) {
    val base = s.thicknessDp.dp.toPx()
    val r = s.cornerRadiusDp.dp.toPx()
    val tail = 0.12f + 0.06f * st.level
    val piece = tail / 3f
    for (k in 0 until 4) {
        val head = (st.phase * 2f + k / 4f) % 1f
        val color = paletteAt(s.palette.colors, k / 4f)
        for (j in 0 until 3) {
            var f0 = head - tail + j * piece
            if (f0 < 0f) f0 += 1f
            val path = paths.loopSegment(size.width, size.height, base, r, f0, f0 + piece)
            val fade = (j + 1) / 3f
            if (s.glow > 0.02f) drawPath(path, color, alpha = a * fade * 0.3f * s.glow,
                style = Stroke(base * (1f + 3f * s.glow), cap = StrokeCap.Round))
            drawPath(path, color, alpha = a * fade, style = Stroke(base * 1.2f, cap = StrokeCap.Round))
        }
    }
}
