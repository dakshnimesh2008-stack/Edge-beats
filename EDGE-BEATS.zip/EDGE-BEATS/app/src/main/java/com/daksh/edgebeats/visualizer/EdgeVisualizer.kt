package com.daksh.edgebeats.visualizer

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import com.daksh.edgebeats.audio.AudioLevels
import com.daksh.edgebeats.data.EdgeSettings
import com.daksh.edgebeats.data.IdleBehavior

/**
 * Single Canvas renderer shared by the overlay and the in-app preview. The frame loop only runs
 * while the effect is active (or for a short decay after going idle) and is cancelled automatically
 * when the composable leaves composition, when animation is paused, or when the window stops
 * producing frames.
 */
@Composable
fun EdgeVisualizer(
    settings: EdgeSettings,
    mode: RenderMode,
    audio: AudioLevels?,
    modifier: Modifier = Modifier
) {
    val state = remember { RenderState() }
    val paths = remember { EdgePaths() }
    var tick by remember { mutableIntStateOf(0) }
    val currentSettings by rememberUpdatedState(settings)
    val currentAudio by rememberUpdatedState(audio)
    val target = when (mode) {
        RenderMode.IDLE -> if (settings.idle == IdleBehavior.DIM_BORDER) 0.25f else 0f
        else -> 1f
    }
    val intensity = animateFloatAsState(target, tween(600), label = "edgeIntensity")

    LaunchedEffect(mode, settings.paused) {
        if (settings.paused) return@LaunchedEffect
        var last = 0L
        var elapsed = 0L
        while (true) {
            val keepGoing = withFrameNanos { now ->
                val dt = if (last == 0L) 0f else (now - last) / 1_000_000_000f
                if (last != 0L) elapsed += now - last
                last = now
                state.advance(dt, currentSettings, mode, currentAudio)
                tick++
                !(mode == RenderMode.IDLE && elapsed > 1_200_000_000L)
            }
            if (!keepGoing) break
        }
    }

    Canvas(modifier.fillMaxSize()) {
        if (tick < 0) return@Canvas
        drawEdgeEffect(settings, state, paths, intensity.value)
    }
}
