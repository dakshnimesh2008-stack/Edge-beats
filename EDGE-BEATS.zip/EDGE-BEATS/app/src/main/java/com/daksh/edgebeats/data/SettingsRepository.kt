package com.daksh.edgebeats.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.edgeDataStore: DataStore<Preferences> by preferencesDataStore(name = "edge_beats_settings")

private val K_STYLE = stringPreferencesKey("style")
private val K_THICK = floatPreferencesKey("thickness")
private val K_BRIGHT = floatPreferencesKey("brightness")
private val K_SPEED = floatPreferencesKey("speed")
private val K_GLOW = floatPreferencesKey("glow")
private val K_RADIUS = floatPreferencesKey("radius")
private val K_SENS = floatPreferencesKey("sensitivity")
private val K_PALETTE = stringPreferencesKey("palette")
private val K_TOP = booleanPreferencesKey("edge_top")
private val K_RIGHT = booleanPreferencesKey("edge_right")
private val K_BOTTOM = booleanPreferencesKey("edge_bottom")
private val K_LEFT = booleanPreferencesKey("edge_left")
private val K_CORNERS = booleanPreferencesKey("corners_only")
private val K_IDLE = stringPreferencesKey("idle")
private val K_PAUSED = booleanPreferencesKey("paused")
private val K_REACTIVE = booleanPreferencesKey("reactive_mode")
private val K_REMEMBER = booleanPreferencesKey("remember_style")
private val K_THEME = stringPreferencesKey("theme")

private inline fun <reified T : Enum<T>> String?.toEnum(default: T): T =
    enumValues<T>().firstOrNull { it.name == this } ?: default

class SettingsRepository(private val store: DataStore<Preferences>) {

    val settings: Flow<EdgeSettings> = store.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { it.toSettings() }
        .distinctUntilChanged()

    suspend fun save(s: EdgeSettings) {
        store.edit { it.write(s.sanitized()) }
    }

    suspend fun restoreDefaults() {
        store.edit { it.clear() }
    }

    /** Called once per process start: when "remember last style" is off, the style returns to the default. */
    suspend fun applyStartupPolicy() {
        store.edit { p ->
            if (!p.toSettings().rememberLastStyle) p[K_STYLE] = EdgeSettings().style.name
        }
    }

    companion object {
        fun create(context: Context) = SettingsRepository(context.applicationContext.edgeDataStore)
    }
}

internal fun Preferences.toSettings(): EdgeSettings {
    val d = EdgeSettings()
    return EdgeSettings(
        style = this[K_STYLE].toEnum(d.style),
        thicknessDp = this[K_THICK] ?: d.thicknessDp,
        brightness = this[K_BRIGHT] ?: d.brightness,
        speed = this[K_SPEED] ?: d.speed,
        glow = this[K_GLOW] ?: d.glow,
        cornerRadiusDp = this[K_RADIUS] ?: d.cornerRadiusDp,
        sensitivity = this[K_SENS] ?: d.sensitivity,
        palette = this[K_PALETTE].toEnum(d.palette),
        top = this[K_TOP] ?: d.top,
        right = this[K_RIGHT] ?: d.right,
        bottom = this[K_BOTTOM] ?: d.bottom,
        left = this[K_LEFT] ?: d.left,
        cornersOnly = this[K_CORNERS] ?: d.cornersOnly,
        idle = this[K_IDLE].toEnum(d.idle),
        paused = this[K_PAUSED] ?: d.paused,
        reactiveMode = this[K_REACTIVE] ?: d.reactiveMode,
        rememberLastStyle = this[K_REMEMBER] ?: d.rememberLastStyle,
        themeMode = this[K_THEME].toEnum(d.themeMode)
    ).sanitized()
}

private fun MutablePreferences.write(s: EdgeSettings) {
    this[K_STYLE] = s.style.name
    this[K_THICK] = s.thicknessDp
    this[K_BRIGHT] = s.brightness
    this[K_SPEED] = s.speed
    this[K_GLOW] = s.glow
    this[K_RADIUS] = s.cornerRadiusDp
    this[K_SENS] = s.sensitivity
    this[K_PALETTE] = s.palette.name
    this[K_TOP] = s.top
    this[K_RIGHT] = s.right
    this[K_BOTTOM] = s.bottom
    this[K_LEFT] = s.left
    this[K_CORNERS] = s.cornersOnly
    this[K_IDLE] = s.idle.name
    this[K_PAUSED] = s.paused
    this[K_REACTIVE] = s.reactiveMode
    this[K_REMEMBER] = s.rememberLastStyle
    this[K_THEME] = s.themeMode.name
}
