package com.daksh.edgebeats.visualizer

import kotlin.math.min

fun clampCornerRadius(radius: Float, w: Float, h: Float, inset: Float): Float {
    val maxR = (min(w, h) / 2f - inset).coerceAtLeast(0f)
    return radius.coerceIn(0f, maxR)
}

fun barMaxLength(w: Float, h: Float): Float = min(w, h) * 0.16f
