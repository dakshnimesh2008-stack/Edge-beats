package com.daksh.edgebeats

import android.app.Application
import com.daksh.edgebeats.data.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class EdgeBeatsApp : Application() {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        appScope.launch { SettingsRepository.create(this@EdgeBeatsApp).applyStartupPolicy() }
    }
}
