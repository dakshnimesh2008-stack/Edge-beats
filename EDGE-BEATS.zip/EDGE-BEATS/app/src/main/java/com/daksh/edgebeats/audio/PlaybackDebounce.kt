package com.daksh.edgebeats.audio

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.transformLatest

const val PLAYBACK_START_DELAY_MS = 150L
const val PLAYBACK_STOP_DELAY_MS = 1200L

/**
 * Stabilises raw "is anything playing" signals. A new value only becomes visible after it has stayed
 * unchanged for its delay; any change in between cancels the pending value (no flicker on rapid
 * playback-configuration changes). Always starts with `false`.
 */
@OptIn(ExperimentalCoroutinesApi::class)
fun Flow<Boolean>.debouncePlayback(
    startDelayMs: Long = PLAYBACK_START_DELAY_MS,
    stopDelayMs: Long = PLAYBACK_STOP_DELAY_MS
): Flow<Boolean> = distinctUntilChanged()
    .transformLatest { raw ->
        delay(if (raw) startDelayMs else stopDelayMs)
        emit(raw)
    }
    .onStart { emit(false) }
    .distinctUntilChanged()
