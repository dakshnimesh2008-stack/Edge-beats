package com.daksh.edgebeats.ui

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.daksh.edgebeats.audio.AudioStatus
import com.daksh.edgebeats.data.EdgeSettings
import com.daksh.edgebeats.data.EdgeStyle
import com.daksh.edgebeats.data.IdleBehavior
import com.daksh.edgebeats.data.Limits
import com.daksh.edgebeats.data.Palette
import com.daksh.edgebeats.data.ThemeMode
import com.daksh.edgebeats.permissions.PermissionState
import com.daksh.edgebeats.permissions.Permissions
import com.daksh.edgebeats.permissions.SetupStep
import com.daksh.edgebeats.permissions.nextSetupStep
import com.daksh.edgebeats.service.EdgeRuntime
import com.daksh.edgebeats.ui.theme.Cyan
import com.daksh.edgebeats.ui.theme.Purple
import com.daksh.edgebeats.ui.theme.Violet

private fun Context.openSafely(intent: android.content.Intent) {
    try {
        startActivity(intent)
    } catch (_: ActivityNotFoundException) {
        startActivity(Permissions.appDetailsIntent(this))
    }
}

@Composable
fun EdgeBeatsApp(vm: MainViewModel) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val perms by vm.permissions.collectAsStateWithLifecycle()
    val running by EdgeRuntime.serviceRunning.collectAsStateWithLifecycle()
    val status by EdgeRuntime.status.collectAsStateWithLifecycle()
    val error by EdgeRuntime.serviceError.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val context = LocalContext.current

    val audioLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refreshPermissions() }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refreshPermissions() }
    val openOverlaySettings = { context.openSafely(Permissions.overlaySettingsIntent(context)) }
    val openAppSettings = { context.openSafely(Permissions.appDetailsIntent(context)) }
    val requestAudio = { audioLauncher.launch(Manifest.permission.RECORD_AUDIO) }
    val requestNotifications = {
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    val setReactive: (Boolean) -> Unit = { on ->
        vm.update { it.copy(reactiveMode = on) }
        if (on && !perms.recordAudio) requestAudio()
    }

    val tabs = listOf("Home" to Icons.Filled.Home, "Styles" to Icons.Filled.Star, "Customize" to Icons.Filled.Build, "Settings" to Icons.Filled.Settings)
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icon, null) }, label = { Text(label) })
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(
                    settings, perms, running, status, error,
                    onToggle = { if (running) vm.stopOverlay() else if (!vm.startOverlay()) openOverlaySettings() },
                    onPause = { vm.update { it.copy(paused = !it.paused) } },
                    onOverlaySettings = openOverlaySettings,
                    onRequestNotifications = requestNotifications,
                    onReactive = setReactive,
                    onOpenStyles = { tab = 1 }
                )
                1 -> StylesScreen(settings) { s -> vm.update { it.copy(style = s) } }
                2 -> CustomizeScreen(settings, vm)
                else -> SettingsScreen(settings, perms, vm, setReactive, openOverlaySettings, openAppSettings)
            }
        }
    }
}

private fun statusColor(s: AudioStatus?, running: Boolean): Color = when {
    !running || s == null -> Color(0xFF6B6B80)
    s == AudioStatus.REACTIVE_AVAILABLE -> Color(0xFF34D399)
    s == AudioStatus.PLAYBACK_DETECTED || s == AudioStatus.PLAYBACK_NO_REACTIVE_DATA -> Cyan
    s == AudioStatus.PERMISSION_UNAVAILABLE -> Color(0xFFF87171)
    else -> Color(0xFF9CA3AF)
}

@Composable
private fun HomeScreen(
    settings: EdgeSettings, perms: PermissionState, running: Boolean, status: AudioStatus?, error: String?,
    onToggle: () -> Unit, onPause: () -> Unit, onOverlaySettings: () -> Unit,
    onRequestNotifications: () -> Unit, onReactive: (Boolean) -> Unit, onOpenStyles: () -> Unit
) {
    val step = nextSetupStep(perms, settings.reactiveMode, running)
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text(
                "EDGE BEATS",
                style = MaterialTheme.typography.headlineMedium.copy(brush = Brush.linearGradient(listOf(Purple, Violet, Cyan)))
            )
            Text("Audio-reactive screen edge visualizer", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Panel {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    PreviewBox(settings, Modifier.width(112.dp).height(236.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Selected style", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(settings.style.label, style = MaterialTheme.typography.titleMedium)
                        Text(settings.style.description, style = MaterialTheme.typography.bodySmall)
                        OutlinedButton(onClick = onOpenStyles) { Text("Change style") }
                    }
                }
            }
        }
        item {
            val (title, detail) = when {
                error != null -> "Overlay stopped" to error
                !running -> "Not monitoring" to "Start EDGE BEATS to detect playback in other apps."
                status == null -> "Starting…" to ""
                else -> status.title to status.detail
            }
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusDot(if (error != null) Color(0xFFF87171) else statusColor(status, running))
                    Text(title, style = MaterialTheme.typography.titleMedium)
                }
                if (detail.isNotEmpty()) Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Overlay permission: ${if (perms.overlay) "granted" else "required"}", style = MaterialTheme.typography.bodySmall)
                Text(
                    "Audio-reactivity: " + when {
                        !settings.reactiveMode -> "off (ambient animation only)"
                        !perms.recordAudio -> "on, permission missing"
                        else -> "on (needs device support)"
                    },
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        item {
            Panel {
                Button(onClick = onToggle, Modifier.fillMaxWidth()) {
                    Text(if (running) "Stop EDGE BEATS" else if (perms.overlay) "Start EDGE BEATS" else "Grant overlay permission")
                }
                OutlinedButton(onClick = onPause, Modifier.fillMaxWidth()) {
                    Text(if (settings.paused) "Resume animation" else "Pause animation")
                }
            }
        }
        if (step != SetupStep.DONE || !perms.notifications) {
            item {
                Panel {
                    Text("Setup", style = MaterialTheme.typography.titleMedium)
                    SetupLine("1. Overlay permission", perms.overlay, "Open settings", onOverlaySettings)
                    SetupLine(
                        "2. Audio permission (only for audio-reactive mode)",
                        !settings.reactiveMode || perms.recordAudio,
                        if (settings.reactiveMode) "Grant" else "Enable reactive mode"
                    ) { onReactive(true) }
                    SetupLine("3. Preview above works without audio", true, "", {})
                    SetupLine("4. Start EDGE BEATS", running, "", {})
                    if (!perms.notifications) SetupLine("Notifications (shows the Stop control)", false, "Allow", onRequestNotifications)
                }
            }
        }
    }
}

@Composable
private fun SetupLine(text: String, done: Boolean, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        StatusDot(if (done) Color(0xFF34D399) else Color(0xFFF59E0B))
        Text(text, Modifier.weight(1f).padding(start = 10.dp), style = MaterialTheme.typography.bodySmall)
        if (!done && action.isNotEmpty()) OutlinedButton(onClick = onClick) { Text(action) }
    }
}

@Composable
private fun StylesScreen(settings: EdgeSettings, onSelect: (EdgeStyle) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { PreviewBox(settings, Modifier.fillMaxWidth().height(180.dp)) }
        items(EdgeStyle.entries) { style ->
            val selected = style == settings.style
            Panel(Modifier.clickable { onSelect(style) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(style.label, style = MaterialTheme.typography.titleMedium)
                        Text(style.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (selected) Text("SELECTED", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CustomizeScreen(s: EdgeSettings, vm: MainViewModel) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { PreviewBox(s, Modifier.fillMaxWidth().height(180.dp)) }
        item {
            Panel {
                SliderRow("Thickness", s.thicknessDp, Limits.THICKNESS, "%.1f dp".format(s.thicknessDp)) { v -> vm.update { it.copy(thicknessDp = v) } }
                SliderRow("Brightness", s.brightness, Limits.BRIGHTNESS, "${(s.brightness * 100).toInt()}%") { v -> vm.update { it.copy(brightness = v) } }
                SliderRow("Speed", s.speed, Limits.SPEED, "%.2fx".format(s.speed)) { v -> vm.update { it.copy(speed = v) } }
                SliderRow("Glow intensity", s.glow, Limits.GLOW, "${(s.glow * 100).toInt()}%") { v -> vm.update { it.copy(glow = v) } }
                SliderRow("Corner radius", s.cornerRadiusDp, Limits.RADIUS, "%.0f dp".format(s.cornerRadiusDp)) { v -> vm.update { it.copy(cornerRadiusDp = v) } }
                SliderRow("Audio sensitivity (real audio data only)", s.sensitivity, Limits.SENSITIVITY, "%.2fx".format(s.sensitivity)) { v -> vm.update { it.copy(sensitivity = v) } }
            }
        }
        item {
            Panel {
                Text("Colour palette", style = MaterialTheme.typography.titleMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Palette.entries.forEach { p ->
                        FilterChip(selected = p == s.palette, onClick = { vm.update { it.copy(palette = p) } }, label = { Text(p.label) })
                    }
                }
            }
        }
        item {
            Panel {
                Text("Edges", style = MaterialTheme.typography.titleMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(s.top, { vm.update { it.copy(top = !it.top) } }, { Text("Top") })
                    FilterChip(s.right, { vm.update { it.copy(right = !it.right) } }, { Text("Right") })
                    FilterChip(s.bottom, { vm.update { it.copy(bottom = !it.bottom) } }, { Text("Bottom") })
                    FilterChip(s.left, { vm.update { it.copy(left = !it.left) } }, { Text("Left") })
                }
                SwitchRow("Corners only", "Border styles draw only near the corners.", s.cornersOnly) { v -> vm.update { it.copy(cornersOnly = v) } }
                Text("When no audio is detected", style = MaterialTheme.typography.titleMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IdleBehavior.entries.forEach { b ->
                        FilterChip(selected = b == s.idle, onClick = { vm.update { it.copy(idle = b) } }, label = { Text(b.label) })
                    }
                }
            }
        }
        item {
            OutlinedButton(onClick = { vm.resetCustomizations() }, Modifier.fillMaxWidth()) { Text("Reset customizations") }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SettingsScreen(
    s: EdgeSettings, perms: PermissionState, vm: MainViewModel,
    onReactive: (Boolean) -> Unit, onOverlaySettings: () -> Unit, onAppSettings: () -> Unit
) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Panel {
                Text("Theme", style = MaterialTheme.typography.titleMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { m ->
                        FilterChip(selected = m == s.themeMode, onClick = { vm.update { it.copy(themeMode = m) } }, label = { Text(m.label) })
                    }
                }
                SwitchRow("Remember last style", "Off: the style resets to the default each time the app starts.", s.rememberLastStyle) { v ->
                    vm.update { it.copy(rememberLastStyle = v) }
                }
                SwitchRow(
                    "Audio-reactive mode",
                    "Asks for the audio permission and tries to read spectrum data via Android's Visualizer API. Nothing is recorded or sent anywhere. Many devices block this for other apps' audio.",
                    s.reactiveMode, onReactive
                )
            }
        }
        item {
            Panel {
                Text("Troubleshooting", style = MaterialTheme.typography.titleMedium)
                Text("• Nothing appears: grant the overlay permission, then press Start.", style = MaterialTheme.typography.bodySmall)
                Text("• Status says reactive data unavailable: your device or the playing app does not expose audio samples. The ambient animation is simulated.", style = MaterialTheme.typography.bodySmall)
                Text("• Effect stops after a while: exclude EDGE BEATS from battery optimisation in system settings.", style = MaterialTheme.typography.bodySmall)
                Text("• Audio permission was denied twice: enable it from app settings.", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onOverlaySettings) { Text("Overlay settings") }
                    OutlinedButton(onClick = onAppSettings) { Text("App settings") }
                }
                Text(
                    "Overlay: ${if (perms.overlay) "granted" else "missing"} · Audio: ${if (perms.recordAudio) "granted" else "not granted"}",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Start
                )
            }
        }
        item {
            OutlinedButton(onClick = { vm.restoreDefaults() }, Modifier.fillMaxWidth()) { Text("Restore all defaults") }
        }
    }
}
