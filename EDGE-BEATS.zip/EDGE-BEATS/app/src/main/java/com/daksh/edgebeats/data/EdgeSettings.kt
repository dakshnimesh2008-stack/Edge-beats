package com.daksh.edgebeats.data

import androidx.compose.ui.graphics.Color

enum class EdgeStyle(val label: String, val description: String) {
    THIN_BORDER("Thin Professional Border", "Clean hairline border that gently brightens with audio."),
    NEON_GLOW("Neon Glow", "Soft multi-layer glow around the whole screen."),
    RGB_GAMING("RGB Gaming Edge", "Fast colour-cycling red/green/blue border."),
    RAINBOW_FLOW("Rainbow Flow", "Slow flowing full-spectrum gradient."),
    EQUALIZER_BARS("Equalizer Bars", "Frequency bars rising from each edge."),
    AUDIO_WAVE("Audio Wave", "Flowing waves along the edges."),
    CORNER_GLOW("Corner Glow", "Light blooms in the corners."),
    MINIMAL_PULSE("Minimal Pulse", "A subtle border that pulses with the beat."),
    DUAL_LINE("Dual-Line Spectrum", "Two lines: bass on the outer, treble on the inner."),
    AMBIENT_GRADIENT("Ambient Gradient", "Colour wash fading in from each edge."),
    CORNER_TRAILS("Four-Corner Light Trails", "Comets of light chasing around the border."),
    MIXED("Custom Mixed", "Border, corner glow and ambient wash combined.")
}

enum class Palette(val label: String, val colors: List<Color>) {
    AURORA("Aurora", listOf(Color(0xFFB026FF), Color(0xFF8B5CF6), Color(0xFF22D3EE))),
    VIOLET("Violet", listOf(Color(0xFF6D28D9), Color(0xFF8B5CF6), Color(0xFFC4B5FD))),
    CYAN("Cyan Ice", listOf(Color(0xFF0891B2), Color(0xFF22D3EE), Color(0xFFA5F3FC))),
    SUNSET("Sunset", listOf(Color(0xFFFF512F), Color(0xFFF09819), Color(0xFFFF2E93))),
    TOXIC("Toxic", listOf(Color(0xFF39FF14), Color(0xFF00FFA3), Color(0xFFCCFF00))),
    RAINBOW("Rainbow", listOf(Color(0xFFFF0000), Color(0xFFFFE600), Color(0xFF00FF55), Color(0xFF00E5FF), Color(0xFF3B5BFF), Color(0xFFFF00E5))),
    MONO("White", listOf(Color.White, Color(0xFFBBBBBB)))
}

enum class ThemeMode(val label: String) { SYSTEM("System"), DARK("Dark"), LIGHT("Light") }

enum class IdleBehavior(val label: String) { HIDDEN("Hidden"), DIM_BORDER("Dim border") }

object Limits {
    val THICKNESS = 1f..16f
    val BRIGHTNESS = 0.1f..1f
    val SPEED = 0.25f..3f
    val GLOW = 0f..1f
    val RADIUS = 0f..48f
    val SENSITIVITY = 0.25f..3f
}

data class EdgeSettings(
    val style: EdgeStyle = EdgeStyle.NEON_GLOW,
    val thicknessDp: Float = 4f,
    val brightness: Float = 0.9f,
    val speed: Float = 1f,
    val glow: Float = 0.6f,
    val cornerRadiusDp: Float = 28f,
    val sensitivity: Float = 1f,
    val palette: Palette = Palette.AURORA,
    val top: Boolean = true,
    val right: Boolean = true,
    val bottom: Boolean = true,
    val left: Boolean = true,
    val cornersOnly: Boolean = false,
    val idle: IdleBehavior = IdleBehavior.HIDDEN,
    val paused: Boolean = false,
    val reactiveMode: Boolean = false,
    val rememberLastStyle: Boolean = true,
    val themeMode: ThemeMode = ThemeMode.SYSTEM
) {
    /** Clamps every numeric value into its valid range and guarantees at least one edge is enabled. */
    fun sanitized(): EdgeSettings {
        val d = EdgeSettings()
        val c = copy(
            thicknessDp = thicknessDp.safe(Limits.THICKNESS, d.thicknessDp),
            brightness = brightness.safe(Limits.BRIGHTNESS, d.brightness),
            speed = speed.safe(Limits.SPEED, d.speed),
            glow = glow.safe(Limits.GLOW, d.glow),
            cornerRadiusDp = cornerRadiusDp.safe(Limits.RADIUS, d.cornerRadiusDp),
            sensitivity = sensitivity.safe(Limits.SENSITIVITY, d.sensitivity)
        )
        return if (!c.top && !c.right && !c.bottom && !c.left) c.copy(top = true, right = true, bottom = true, left = true) else c
    }

    /** Resets visual customisation but keeps style, theme and behavioural switches. */
    fun resetCustomizations(): EdgeSettings = EdgeSettings(
        style = style, reactiveMode = reactiveMode, rememberLastStyle = rememberLastStyle,
        themeMode = themeMode, paused = paused
    )
}

private fun Float.safe(range: ClosedFloatingPointRange<Float>, default: Float): Float =
    if (isFinite()) coerceIn(range.start, range.endInclusive) else default
