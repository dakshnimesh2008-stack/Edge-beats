package com.daksh.edgebeats.audio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.AudioPlaybackConfiguration
import android.media.audiofx.Visualizer
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

/**
 * Detects playback (AudioPlaybackCallback) and, only if the user opted in and granted the audio
 * permission, tries to read spectrum data through the Visualizer API. Detection and reactivity are
 * separate: playback can be detected while no samples are available. Nothing is recorded or stored.
 */
class AudioMonitor(
    private val context: Context,
    private val scope: CoroutineScope,
    private val levels: AudioLevels
) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val rawPlaying = MutableStateFlow(false)
    private val reactiveRequested = MutableStateFlow(false)
    private val permission = MutableStateFlow(hasRecordPermission())
    private val signal = MutableStateFlow(false)
    private val _status = MutableStateFlow(AudioStatus.NO_PLAYBACK)
    val status: StateFlow<AudioStatus> = _status.asStateFlow()

    private var visualizer: Visualizer? = null
    private var job: Job? = null
    private var registered = false
    private var lastLoudMs = 0L
    private val scratch = FloatArray(BAND_COUNT)

    private val callback = object : AudioManager.AudioPlaybackCallback() {
        override fun onPlaybackConfigChanged(configs: MutableList<AudioPlaybackConfiguration>) {
            rawPlaying.value = configs.isNotEmpty()
        }
    }

    fun setReactive(enabled: Boolean) {
        reactiveRequested.value = enabled
    }

    fun refreshPermission() {
        permission.value = hasRecordPermission()
    }

    fun start() {
        if (job != null) return
        audioManager.registerAudioPlaybackCallback(callback, Handler(Looper.getMainLooper()))
        registered = true
        rawPlaying.value = audioManager.activePlaybackConfigurations.isNotEmpty()
        job = scope.launch {
            val playing = rawPlaying.debouncePlayback()
            launch {
                combine(playing, reactiveRequested, permission) { p, r, perm -> p && r && perm }
                    .distinctUntilChanged()
                    .collect { wanted -> if (wanted) startVisualizer() else stopVisualizer() }
            }
            combine(playing, reactiveRequested, permission, signal) { p, r, perm, s ->
                resolveAudioStatus(p, r, perm, s)
            }.collect { _status.value = it }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        if (registered) {
            audioManager.unregisterAudioPlaybackCallback(callback)
            registered = false
        }
        stopVisualizer()
        levels.clear()
        _status.value = AudioStatus.NO_PLAYBACK
    }

    private fun hasRecordPermission() =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startVisualizer() {
        stopVisualizer()
        try {
            val v = Visualizer(0) // output mix; many devices/Android versions restrict or silence this
            val size = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
            v.setCaptureSize(size)
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vis: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
                override fun onFftDataCapture(vis: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft == null) return
                    fftToBands(fft, scratch)
                    var sum = 0f
                    for (i in scratch.indices) {
                        levels.bands[i] = scratch[i]
                        sum += scratch[i]
                    }
                    val avg = sum / scratch.size
                    levels.level = avg
                    val now = SystemClock.elapsedRealtime()
                    if (avg > 0.03f) {
                        lastLoudMs = now
                        signal.value = true
                    } else if (now - lastLoudMs > 2000L) {
                        signal.value = false
                    }
                }
            }, Visualizer.getMaxCaptureRate(), false, true)
            v.setEnabled(true)
            visualizer = v
        } catch (e: Exception) {
            // Unsupported device, blocked session 0, or permission problem: stay in ambient mode.
            visualizer = null
            signal.value = false
        }
    }

    private fun stopVisualizer() {
        visualizer?.let {
            try {
                it.setEnabled(false)
                it.release()
            } catch (_: Exception) {
            }
        }
        visualizer = null
        signal.value = false
        levels.clear()
    }
}
