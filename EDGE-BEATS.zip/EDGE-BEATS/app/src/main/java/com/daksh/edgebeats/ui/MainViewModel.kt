package com.daksh.edgebeats.ui

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.daksh.edgebeats.data.EdgeSettings
import com.daksh.edgebeats.data.SettingsRepository
import com.daksh.edgebeats.permissions.PermissionState
import com.daksh.edgebeats.permissions.Permissions
import com.daksh.edgebeats.service.EdgeRuntime
import com.daksh.edgebeats.service.EdgeService
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@OptIn(FlowPreview::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepository.create(app)
    private val _settings = MutableStateFlow(EdgeSettings())
    val settings: StateFlow<EdgeSettings> = _settings.asStateFlow()
    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded.asStateFlow()
    private val _permissions = MutableStateFlow(Permissions.read(app))
    val permissions: StateFlow<PermissionState> = _permissions.asStateFlow()

    init {
        viewModelScope.launch {
            _settings.value = repo.settings.first()
            _loaded.value = true
            // UI edits apply instantly in memory; disk writes are debounced and off the main thread.
            _settings.debounce(300).collect { repo.save(it) }
        }
    }

    fun update(transform: (EdgeSettings) -> EdgeSettings) {
        _settings.update { transform(it).sanitized() }
    }

    fun resetCustomizations() = update { it.resetCustomizations() }

    fun restoreDefaults() {
        _settings.value = EdgeSettings()
    }

    fun refreshPermissions() {
        val p = Permissions.read(getApplication())
        _permissions.value = p
        if (!p.overlay && EdgeRuntime.serviceRunning.value) {
            EdgeRuntime.serviceError.value = "Overlay permission was revoked."
            stopOverlay()
        }
    }

    /** Returns false when overlay permission is missing (the caller then opens system settings). */
    fun startOverlay(): Boolean {
        refreshPermissions()
        if (!_permissions.value.canStartOverlay) return false
        EdgeRuntime.serviceError.value = null
        val app = getApplication<Application>()
        ContextCompat.startForegroundService(app, Intent(app, EdgeService::class.java))
        return true
    }

    fun stopOverlay() {
        val app = getApplication<Application>()
        app.stopService(Intent(app, EdgeService::class.java))
    }
}
