package com.daksh.edgebeats.service

import com.daksh.edgebeats.audio.AudioLevels
import com.daksh.edgebeats.audio.AudioStatus
import kotlinx.coroutines.flow.MutableStateFlow

/** Process-wide runtime state shared between the service and the UI. Only reflects real state. */
object EdgeRuntime {
    val levels = AudioLevels()
    val serviceRunning = MutableStateFlow(false)
    /** Null while the service is not monitoring. */
    val status = MutableStateFlow<AudioStatus?>(null)
    val serviceError = MutableStateFlow<String?>(null)
}
