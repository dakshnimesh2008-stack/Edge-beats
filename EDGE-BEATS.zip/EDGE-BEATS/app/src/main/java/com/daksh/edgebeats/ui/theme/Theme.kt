package com.daksh.edgebeats.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.daksh.edgebeats.data.ThemeMode

val Violet = Color(0xFF8B5CF6)
val Cyan = Color(0xFF22D3EE)
val Purple = Color(0xFFB026FF)

private val DarkScheme = darkColorScheme(
    primary = Violet, secondary = Cyan, tertiary = Purple,
    background = Color.Black, surface = Color(0xFF0B0B10), surfaceVariant = Color(0xFF15151E),
    onBackground = Color(0xFFF2F2F7), onSurface = Color(0xFFF2F2F7), onSurfaceVariant = Color(0xFFA9A9BD),
    outline = Color(0xFF33334A)
)
private val LightScheme = lightColorScheme(
    primary = Color(0xFF6D3AF0), secondary = Color(0xFF0891B2), tertiary = Color(0xFF9D00E0),
    background = Color(0xFFF7F6FB), surface = Color.White, surfaceVariant = Color(0xFFECEAF6)
)

private val EdgeTypography = Typography(
    headlineMedium = TextStyle(fontWeight = FontWeight.Black, fontSize = 30.sp, letterSpacing = 5.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, letterSpacing = 0.4.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, letterSpacing = 1.2.sp)
)

@Composable
fun EdgeBeatsTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, typography = EdgeTypography, content = content)
}
