package com.daksh.edgebeats.audio

import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sqrt

const val BAND_COUNT = 16

/** Lock-free holder written by the Visualizer thread and read by the render loop. */
class AudioLevels {
    val bands = FloatArray(BAND_COUNT)
    @Volatile var level = 0f

    fun clear() {
        bands.fill(0f)
        level = 0f
    }
}

/**
 * Converts Visualizer FFT bytes (Re/Im pairs after two header bytes) into [out].size log-spaced
 * bands normalised to 0..1. Pure function.
 */
fun fftToBands(fft: ByteArray, out: FloatArray) {
    val bins = (fft.size - 2) / 2
    if (bins < 1 || out.isEmpty()) {
        out.fill(0f)
        return
    }
    val count = out.size
    fun edge(b: Int): Int =
        if (b >= count) bins else (bins.toDouble().pow(b.toDouble() / count)).toInt() - 1
    for (b in 0 until count) {
        val lo = edge(b).coerceIn(0, bins - 1)
        val hi = edge(b + 1).coerceIn(lo + 1, bins)
        var sum = 0f
        for (k in lo until hi) {
            sum += hypot(fft[2 + 2 * k].toFloat(), fft[3 + 2 * k].toFloat())
        }
        val avg = sum / (hi - lo)
        out[b] = (sqrt(avg) / 8f).coerceIn(0f, 1f)
    }
}
