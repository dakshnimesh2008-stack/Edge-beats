package com.daksh.edgebeats.permissions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat

data class PermissionState(
    val overlay: Boolean,
    val recordAudio: Boolean,
    val notifications: Boolean
) {
    val canStartOverlay: Boolean get() = overlay
}

enum class SetupStep { OVERLAY, AUDIO, ACTIVATE, DONE }

/** Next required setup step; audio is only required when the user wants audio-reactive mode. */
fun nextSetupStep(p: PermissionState, reactiveWanted: Boolean, running: Boolean): SetupStep = when {
    !p.overlay -> SetupStep.OVERLAY
    reactiveWanted && !p.recordAudio -> SetupStep.AUDIO
    !running -> SetupStep.ACTIVATE
    else -> SetupStep.DONE
}

object Permissions {
    fun read(context: Context): PermissionState = PermissionState(
        overlay = Settings.canDrawOverlays(context),
        recordAudio = granted(context, Manifest.permission.RECORD_AUDIO),
        notifications = Build.VERSION.SDK_INT < 33 || granted(context, Manifest.permission.POST_NOTIFICATIONS)
    )

    fun overlaySettingsIntent(context: Context): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun appDetailsIntent(context: Context): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    private fun granted(context: Context, permission: String) =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}
