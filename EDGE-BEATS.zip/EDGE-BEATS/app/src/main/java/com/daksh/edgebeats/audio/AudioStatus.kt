package com.daksh.edgebeats.audio

enum class AudioStatus(val title: String, val detail: String) {
    NO_PLAYBACK("No supported playback detected", "Play audio in another app. The edge effect wakes up automatically."),
    PLAYBACK_DETECTED("Playback detected", "Audio is playing. Edge effects use a simulated ambient animation because audio-reactive mode is off."),
    REACTIVE_AVAILABLE("Audio-reactive data available", "Edge effects are following the real audio spectrum."),
    PLAYBACK_NO_REACTIVE_DATA("Playback detected, reactive data unavailable", "Android is not providing audio samples right now. Showing an ambient animation, not a real waveform."),
    PERMISSION_UNAVAILABLE("Required permission unavailable", "Audio-reactive mode needs the audio permission. Grant it or turn reactive mode off.")
}

/** Pure status resolution so it can be unit-tested. */
fun resolveAudioStatus(
    playing: Boolean,
    reactiveRequested: Boolean,
    permissionGranted: Boolean,
    reactiveSignal: Boolean
): AudioStatus = when {
    reactiveRequested && !permissionGranted -> AudioStatus.PERMISSION_UNAVAILABLE
    !playing -> AudioStatus.NO_PLAYBACK
    !reactiveRequested -> AudioStatus.PLAYBACK_DETECTED
    reactiveSignal -> AudioStatus.REACTIVE_AVAILABLE
    else -> AudioStatus.PLAYBACK_NO_REACTIVE_DATA
}
