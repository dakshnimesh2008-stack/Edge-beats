package com.daksh.edgebeats.visualizer

import com.daksh.edgebeats.audio.AudioLevels
import com.daksh.edgebeats.audio.BAND_COUNT
import com.daksh.edgebeats.data.EdgeSettings
import kotlin.math.exp
import kotlin.math.sin

/** Mutable per-frame animation state. Not Compose state: read only from the draw phase. */
class RenderState {
    val bands = FloatArray(BAND_COUNT)
    var level = 0f
    var low = 0f
    var high = 0f
    var phase = 0f // revolutions, 0..1
    var time = 0f

    fun band(fraction: Float): Float = bands[(fraction.coerceIn(0f, 0.999f) * bands.size).toInt()]

    fun advance(dt: Float, s: EdgeSettings, mode: RenderMode, audio: AudioLevels?) {
        val d = dt.coerceIn(0f, 0.1f)
        val moving = mode != RenderMode.IDLE
        if (moving) time += d * s.speed
        for (i in bands.indices) {
            val target = when (mode) {
                RenderMode.REACTIVE -> ((audio?.bands?.get(i) ?: 0f) * s.sensitivity).coerceIn(0f, 1f)
                RenderMode.AMBIENT, RenderMode.PREVIEW -> ambientValue(i, time)
                RenderMode.IDLE -> 0f
            }
            val rate = if (target > bands[i]) 30f else 8f
            bands[i] += (target - bands[i]) * (1f - exp(-d * rate))
        }
        level = bands.average().toFloat()
        low = (0 until 5).sumOf { bands[it].toDouble() }.toFloat() / 5f
        high = (8 until bands.size).sumOf { bands[it].toDouble() }.toFloat() / (bands.size - 8)
        if (moving) phase = (phase + d * s.speed * (0.06f + 0.22f * level)) % 1f
    }
}

/** Clearly simulated motion used when no real audio samples exist. */
internal fun ambientValue(i: Int, t: Float): Float {
    val a = 0.5f + 0.5f * sin(t * 1.7f + i * 0.62f)
    val b = 0.5f + 0.5f * sin(t * 0.9f + i * 1.31f + 1.7f)
    return (0.15f + 0.55f * a * b + 0.2f * a).coerceIn(0f, 1f)
}
