package com.daksh.edgebeats.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.daksh.edgebeats.data.EdgeSettings
import com.daksh.edgebeats.service.EdgeRuntime
import com.daksh.edgebeats.visualizer.EdgeVisualizer
import com.daksh.edgebeats.visualizer.RenderMode

/**
 * Owns exactly one non-touchable, non-focusable overlay window. It is created once and reused;
 * only state changes while it lives. It draws only along the screen perimeter.
 */
class OverlayController(private val context: Context) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val owner = OverlayOwner()
    private var view: ComposeView? = null
    private var settings by mutableStateOf(EdgeSettings())
    private var mode by mutableStateOf(RenderMode.IDLE)

    fun attach(): Boolean {
        if (view != null) return true
        val v = ComposeView(context).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setContent { EdgeVisualizer(settings, mode, EdgeRuntime.levels) }
        }
        owner.resume()
        return try {
            windowManager.addView(v, layoutParams())
            view = v
            true
        } catch (e: Exception) { // BadTokenException / SecurityException when permission was revoked
            owner.destroy()
            false
        }
    }

    fun update(newSettings: EdgeSettings, newMode: RenderMode) {
        settings = newSettings
        mode = newMode
    }

    fun detach() {
        view?.let {
            try {
                windowManager.removeViewImmediate(it)
            } catch (_: Exception) {
            }
            it.disposeComposition()
        }
        view = null
        owner.destroy()
    }

    private fun layoutParams(): WindowManager.LayoutParams {
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            title = "EDGE BEATS overlay"
            // Android 12+ lets touches pass through overlays only up to 0.8 opacity; this overlay never takes touches.
            if (Build.VERSION.SDK_INT >= 31) alpha = 0.8f
            layoutInDisplayCutoutMode = when {
                Build.VERSION.SDK_INT >= 30 -> WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                Build.VERSION.SDK_INT >= 28 -> WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                else -> layoutInDisplayCutoutMode
            }
        }
    }
}
