package com.daksh.edgebeats.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.daksh.edgebeats.MainActivity
import com.daksh.edgebeats.R
import com.daksh.edgebeats.audio.AudioMonitor
import com.daksh.edgebeats.data.SettingsRepository
import com.daksh.edgebeats.overlay.OverlayController
import com.daksh.edgebeats.visualizer.selectRenderMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/** User-started foreground service that hosts the overlay and audio monitor. Stops itself on failure. */
class EdgeService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var monitor: AudioMonitor? = null
    private var overlay: OverlayController? = null
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground() // must happen quickly after startForegroundService
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY
        if (!Settings.canDrawOverlays(this)) return fail("Overlay permission is not granted.")

        val ov = OverlayController(this)
        if (!ov.attach()) return fail("Android refused to show the overlay. Check the overlay permission.")
        overlay = ov
        val m = AudioMonitor(applicationContext, scope, EdgeRuntime.levels).also { it.start() }
        monitor = m
        running = true
        EdgeRuntime.serviceError.value = null
        EdgeRuntime.serviceRunning.value = true

        val repo = SettingsRepository.create(this)
        scope.launch {
            combine(repo.settings, m.status) { s, st -> s to st }.collect { (s, st) ->
                if (!Settings.canDrawOverlays(this@EdgeService)) {
                    fail("Overlay permission was revoked.")
                    return@collect
                }
                m.setReactive(s.reactiveMode)
                m.refreshPermission()
                EdgeRuntime.status.value = st
                ov.update(s, selectRenderMode(st, preview = false))
            }
        }
        return START_NOT_STICKY
    }

    private fun fail(message: String): Int {
        EdgeRuntime.serviceError.value = message
        stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        monitor?.stop()
        overlay?.detach()
        monitor = null
        overlay = null
        running = false
        EdgeRuntime.serviceRunning.value = false
        EdgeRuntime.status.value = null
        EdgeRuntime.levels.clear()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "EDGE BEATS overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, EdgeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_edge)
            .setContentTitle("EDGE BEATS is active")
            .setContentText("Edge visualizer overlay is running.")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, n, type)
    }

    companion object {
        const val ACTION_STOP = "com.daksh.edgebeats.action.STOP"
        private const val CHANNEL_ID = "edge_beats_overlay"
        private const val NOTIFICATION_ID = 17
    }
}
