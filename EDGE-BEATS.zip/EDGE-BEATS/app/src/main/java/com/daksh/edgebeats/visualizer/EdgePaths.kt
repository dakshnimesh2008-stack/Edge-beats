package com.daksh.edgebeats.visualizer

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import com.daksh.edgebeats.data.EdgeSettings
import kotlin.math.hypot
import kotlin.math.min

/** Caches border paths so nothing is rebuilt per frame unless size or settings change. */
class EdgePaths {
    private data class Key(
        val w: Float, val h: Float, val inset: Float, val r: Float,
        val cornersOnly: Boolean, val top: Boolean, val right: Boolean, val bottom: Boolean, val left: Boolean
    )

    private val cache = HashMap<Key, Path>()
    private val measure = PathMeasure()
    private val dest = Path()
    private var loopKey: List<Float>? = null

    fun get(w: Float, h: Float, inset: Float, radius: Float, s: EdgeSettings): Path {
        val r = clampCornerRadius(radius, w, h, inset)
        val key = Key(w, h, inset, r, s.cornersOnly, s.top, s.right, s.bottom, s.left)
        if (cache.size > 8) cache.clear()
        return cache.getOrPut(key) { build(key) }
    }

    private fun build(k: Key): Path {
        val p = Path()
        val l = k.inset
        val t = k.inset
        val rt = k.w - k.inset
        val b = k.h - k.inset
        val r = k.r
        val seg = min(k.w, k.h) * 0.18f

        fun edge(x1: Float, y1: Float, x2: Float, y2: Float) {
            if (!k.cornersOnly) {
                p.moveTo(x1, y1); p.lineTo(x2, y2)
            } else {
                val len = hypot(x2 - x1, y2 - y1).coerceAtLeast(1f)
                val f = min(seg / len, 0.5f)
                p.moveTo(x1, y1); p.lineTo(x1 + (x2 - x1) * f, y1 + (y2 - y1) * f)
                p.moveTo(x2, y2); p.lineTo(x2 - (x2 - x1) * f, y2 - (y2 - y1) * f)
            }
        }

        fun arc(cx: Float, cy: Float, start: Float, a: Boolean, c: Boolean) {
            val show = if (k.cornersOnly) (a || c) else (a && c)
            if (show && r >= 1f) p.arcTo(Rect(cx - r, cy - r, cx + r, cy + r), start, 90f, true)
        }

        if (k.top) edge(l + r, t, rt - r, t)
        if (k.right) edge(rt, t + r, rt, b - r)
        if (k.bottom) edge(rt - r, b, l + r, b)
        if (k.left) edge(l, b - r, l, t + r)
        arc(l + r, t + r, 180f, k.top, k.left)
        arc(rt - r, t + r, 270f, k.top, k.right)
        arc(rt - r, b - r, 0f, k.bottom, k.right)
        arc(l + r, b - r, 90f, k.bottom, k.left)
        return p
    }

    /** Closed rounded-rectangle loop used by the light trails. Returns the segment [f0, f1] (fractions, may exceed 1 to wrap). */
    fun loopSegment(w: Float, h: Float, inset: Float, radius: Float, f0: Float, f1: Float): Path {
        val r = clampCornerRadius(radius, w, h, inset)
        val key = listOf(w, h, inset, r)
        if (key != loopKey) {
            val loop = Path().apply { addRoundRect(RoundRect(inset, inset, w - inset, h - inset, CornerRadius(r))) }
            measure.setPath(loop, true)
            loopKey = key
        }
        val len = measure.length
        dest.rewind()
        val s = f0 * len
        val e = f1 * len
        if (e <= len) {
            measure.getSegment(s, e, dest, true)
        } else {
            measure.getSegment(s, len, dest, true)
            measure.getSegment(0f, e - len, dest, true)
        }
        return dest
    }
}
