package com.daksh.edgebeats.visualizer

import com.daksh.edgebeats.audio.AudioStatus

enum class RenderMode { REACTIVE, AMBIENT, PREVIEW, IDLE }

/** REACTIVE = real audio data. AMBIENT = playback only (simulated motion). PREVIEW = in-app simulation. */
fun selectRenderMode(status: AudioStatus?, preview: Boolean): RenderMode = when {
    preview -> RenderMode.PREVIEW
    status == AudioStatus.REACTIVE_AVAILABLE -> RenderMode.REACTIVE
    status == AudioStatus.PLAYBACK_DETECTED || status == AudioStatus.PLAYBACK_NO_REACTIVE_DATA -> RenderMode.AMBIENT
    else -> RenderMode.IDLE
}
