package com.daksh.edgebeats

import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertEquals
import org.junit.Test

class PackageInstrumentedTest {
    @Test
    fun applicationIdIsCorrect() {
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        assertEquals("com.daksh.edgebeats", ctx.packageName)
    }
}
