package com.daksh.edgebeats

import com.daksh.edgebeats.audio.debouncePlayback
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class PlaybackDebounceTest {
    @Test
    fun startIsDelayedThenCommitted() = runTest {
        val raw = MutableStateFlow(false)
        val out = mutableListOf<Boolean>()
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { raw.debouncePlayback(150, 1200).toList(out) }
        runCurrent()
        raw.value = true
        advanceTimeBy(100); runCurrent()
        assertEquals(listOf(false), out)
        advanceTimeBy(100); runCurrent()
        assertEquals(listOf(false, true), out)
    }

    @Test
    fun stopIsDelayed() = runTest {
        val raw = MutableStateFlow(false)
        val out = mutableListOf<Boolean>()
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { raw.debouncePlayback(150, 1200).toList(out) }
        runCurrent()
        raw.value = true
        advanceTimeBy(200); runCurrent()
        raw.value = false
        advanceTimeBy(1000); runCurrent()
        assertEquals(listOf(false, true), out)
        advanceTimeBy(300); runCurrent()
        assertEquals(listOf(false, true, false), out)
    }

    @Test
    fun rapidFlappingDoesNotEmitStop() = runTest {
        val raw = MutableStateFlow(false)
        val out = mutableListOf<Boolean>()
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { raw.debouncePlayback(150, 1200).toList(out) }
        runCurrent()
        raw.value = true
        advanceTimeBy(200); runCurrent()
        repeat(5) {
            raw.value = false
            advanceTimeBy(300); runCurrent()
            raw.value = true
            advanceTimeBy(300); runCurrent()
        }
        advanceTimeBy(5000); runCurrent()
        assertEquals(listOf(false, true), out)
    }

    @Test
    fun brieflyTrueNeverBecomesVisible() = runTest {
        val raw = MutableStateFlow(false)
        val out = mutableListOf<Boolean>()
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { raw.debouncePlayback(150, 1200).toList(out) }
        runCurrent()
        raw.value = true
        advanceTimeBy(100); runCurrent()
        raw.value = false
        advanceTimeBy(5000); runCurrent()
        assertEquals(listOf(false), out)
    }

    @Test
    fun cancellingCollectorStopsEmissions() = runTest {
        val raw = MutableStateFlow(false)
        val out = mutableListOf<Boolean>()
        val job = backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { raw.debouncePlayback(150, 1200).toList(out) }
        runCurrent()
        raw.value = true
        advanceTimeBy(50); runCurrent()
        job.cancel()
        advanceTimeBy(5000); runCurrent()
        assertEquals(listOf(false), out)
    }
}
