package com.daksh.edgebeats

import com.daksh.edgebeats.audio.AudioStatus
import com.daksh.edgebeats.audio.BAND_COUNT
import com.daksh.edgebeats.audio.fftToBands
import com.daksh.edgebeats.audio.resolveAudioStatus
import com.daksh.edgebeats.visualizer.RenderMode
import com.daksh.edgebeats.visualizer.barMaxLength
import com.daksh.edgebeats.visualizer.clampCornerRadius
import com.daksh.edgebeats.visualizer.selectRenderMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AudioLogicTest {
    @Test fun noPlayback() =
        assertEquals(AudioStatus.NO_PLAYBACK, resolveAudioStatus(false, false, false, false))

    @Test fun playbackWithoutReactiveMode() =
        assertEquals(AudioStatus.PLAYBACK_DETECTED, resolveAudioStatus(true, false, false, false))

    @Test fun reactiveDataAvailable() =
        assertEquals(AudioStatus.REACTIVE_AVAILABLE, resolveAudioStatus(true, true, true, true))

    @Test fun reactiveRequestedButNoData() =
        assertEquals(AudioStatus.PLAYBACK_NO_REACTIVE_DATA, resolveAudioStatus(true, true, true, false))

    @Test fun permissionMissingWins() {
        assertEquals(AudioStatus.PERMISSION_UNAVAILABLE, resolveAudioStatus(true, true, false, true))
        assertEquals(AudioStatus.PERMISSION_UNAVAILABLE, resolveAudioStatus(false, true, false, false))
    }

    @Test fun renderModeSelection() {
        assertEquals(RenderMode.PREVIEW, selectRenderMode(AudioStatus.REACTIVE_AVAILABLE, preview = true))
        assertEquals(RenderMode.REACTIVE, selectRenderMode(AudioStatus.REACTIVE_AVAILABLE, false))
        assertEquals(RenderMode.AMBIENT, selectRenderMode(AudioStatus.PLAYBACK_DETECTED, false))
        assertEquals(RenderMode.AMBIENT, selectRenderMode(AudioStatus.PLAYBACK_NO_REACTIVE_DATA, false))
        assertEquals(RenderMode.IDLE, selectRenderMode(AudioStatus.NO_PLAYBACK, false))
        assertEquals(RenderMode.IDLE, selectRenderMode(AudioStatus.PERMISSION_UNAVAILABLE, false))
        assertEquals(RenderMode.IDLE, selectRenderMode(null, false))
    }

    @Test fun fftSilenceGivesZeroBands() {
        val out = FloatArray(BAND_COUNT) { 1f }
        fftToBands(ByteArray(1024), out)
        assertTrue(out.all { it == 0f })
    }

    @Test fun fftEnergyShowsUpInBoundedBands() {
        val fft = ByteArray(1024)
        fft[2 + 2 * 10] = 100
        fft[3 + 2 * 10] = 50
        val out = FloatArray(BAND_COUNT)
        fftToBands(fft, out)
        assertTrue(out.any { it > 0f })
        assertTrue(out.all { it in 0f..1f })
    }

    @Test fun tinyFftBufferIsSafe() {
        val out = FloatArray(BAND_COUNT) { 1f }
        fftToBands(ByteArray(2), out)
        assertTrue(out.all { it == 0f })
    }

    @Test fun geometryHandlesOrientationAndSizeChanges() {
        assertEquals(barMaxLength(1080f, 2400f), barMaxLength(2400f, 1080f), 0.001f)
        assertEquals(20f, clampCornerRadius(20f, 1080f, 2400f, 2f), 0.001f)
        assertEquals(538f, clampCornerRadius(5000f, 1080f, 2400f, 2f), 0.001f)
        assertEquals(0f, clampCornerRadius(10f, 2f, 2f, 5f), 0.001f)
    }
}
