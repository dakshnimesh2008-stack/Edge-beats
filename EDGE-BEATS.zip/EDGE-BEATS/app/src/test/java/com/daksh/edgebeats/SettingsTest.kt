package com.daksh.edgebeats

import com.daksh.edgebeats.data.EdgeSettings
import com.daksh.edgebeats.data.EdgeStyle
import com.daksh.edgebeats.data.IdleBehavior
import com.daksh.edgebeats.data.Palette
import com.daksh.edgebeats.data.SettingsRepository
import com.daksh.edgebeats.data.ThemeMode
import com.daksh.edgebeats.permissions.PermissionState
import com.daksh.edgebeats.permissions.SetupStep
import com.daksh.edgebeats.permissions.nextSetupStep
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class SettingsTest {
    @get:Rule val tmp = TemporaryFolder()

    @Test fun sanitizedClampsRanges() {
        val s = EdgeSettings(thicknessDp = 999f, brightness = -3f, speed = 99f, glow = 5f, cornerRadiusDp = -1f, sensitivity = 0f).sanitized()
        assertEquals(16f, s.thicknessDp, 0f)
        assertEquals(0.1f, s.brightness, 0f)
        assertEquals(3f, s.speed, 0f)
        assertEquals(1f, s.glow, 0f)
        assertEquals(0f, s.cornerRadiusDp, 0f)
        assertEquals(0.25f, s.sensitivity, 0f)
    }

    @Test fun sanitizedReplacesNaNWithDefaults() {
        val s = EdgeSettings(thicknessDp = Float.NaN, speed = Float.POSITIVE_INFINITY).sanitized()
        assertEquals(EdgeSettings().thicknessDp, s.thicknessDp, 0f)
        assertEquals(EdgeSettings().speed, s.speed, 0f)
    }

    @Test fun atLeastOneEdgeStaysEnabled() {
        val s = EdgeSettings(top = false, right = false, bottom = false, left = false).sanitized()
        assertTrue(s.top && s.right && s.bottom && s.left)
    }

    @Test fun resetCustomizationsKeepsStyleAndTheme() {
        val s = EdgeSettings(style = EdgeStyle.AUDIO_WAVE, thicknessDp = 12f, palette = Palette.SUNSET, themeMode = ThemeMode.DARK, reactiveMode = true)
            .resetCustomizations()
        assertEquals(EdgeStyle.AUDIO_WAVE, s.style)
        assertEquals(ThemeMode.DARK, s.themeMode)
        assertTrue(s.reactiveMode)
        assertEquals(EdgeSettings().thicknessDp, s.thicknessDp, 0f)
        assertEquals(Palette.AURORA, s.palette)
    }

    @Test fun preferencesPersistAndRestore() = runBlocking {
        val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        try {
            val file = File(tmp.root, "t.preferences_pb")
            val repo = SettingsRepository(PreferenceDataStoreFactory.create(scope = scope) { file })
            val saved = EdgeSettings(
                style = EdgeStyle.CORNER_TRAILS, thicknessDp = 7f, palette = Palette.TOXIC, bottom = false,
                cornersOnly = true, idle = IdleBehavior.DIM_BORDER, paused = true, reactiveMode = true, themeMode = ThemeMode.LIGHT
            )
            repo.save(saved)
            assertEquals(saved, repo.settings.first())
            repo.restoreDefaults()
            assertEquals(EdgeSettings(), repo.settings.first())
        } finally {
            scope.cancel()
        }
    }

    @Test fun rememberStyleOffResetsStyleOnStartup() = runBlocking {
        val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        try {
            val repo = SettingsRepository(PreferenceDataStoreFactory.create(scope = scope) { File(tmp.root, "r.preferences_pb") })
            repo.save(EdgeSettings(style = EdgeStyle.RGB_GAMING, rememberLastStyle = false))
            repo.applyStartupPolicy()
            assertEquals(EdgeSettings().style, repo.settings.first().style)
            repo.save(EdgeSettings(style = EdgeStyle.RGB_GAMING, rememberLastStyle = true))
            repo.applyStartupPolicy()
            assertEquals(EdgeStyle.RGB_GAMING, repo.settings.first().style)
        } finally {
            scope.cancel()
        }
    }

    @Test fun overlayPermissionGatesStart() {
        val none = PermissionState(overlay = false, recordAudio = false, notifications = true)
        assertFalse(none.canStartOverlay)
        assertEquals(SetupStep.OVERLAY, nextSetupStep(none, reactiveWanted = false, running = false))
        val overlayOnly = none.copy(overlay = true)
        assertTrue(overlayOnly.canStartOverlay)
        assertEquals(SetupStep.AUDIO, nextSetupStep(overlayOnly, reactiveWanted = true, running = false))
        assertEquals(SetupStep.ACTIVATE, nextSetupStep(overlayOnly, reactiveWanted = false, running = false))
        assertEquals(SetupStep.DONE, nextSetupStep(overlayOnly, reactiveWanted = false, running = true))
    }
}
